from ihatemoney.run import create_app

application = create_app()
